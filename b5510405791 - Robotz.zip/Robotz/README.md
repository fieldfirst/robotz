# Robotz
> This project is my assignment during an Automata course, so feel free to fork :D

**Please note that, this project is still under a heavy development**

#### License terms :

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">Robotz</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="https://github.com/fieldfirst/Robotz" property="cc:attributionName" rel="cc:attributionURL">Voravut Nateluercha</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.<br />Based on a work at <a xmlns:dct="http://purl.org/dc/terms/" href="https://github.com/fieldfirst/Robotz" rel="dct:source">https://github.com/fieldfirst/Robotz</a>.<br />Permissions beyond the scope of this license may be available at <a xmlns:cc="http://creativecommons.org/ns#" href="https://github.com/fieldfirst/Robotz" rel="cc:morePermissions">https://github.com/fieldfirst/Robotz</a>.

#### Screenshot :
![alt text][logo]
[logo]: https://github.com/fieldfirst/Robotz/blob/master/Screenshot-Mac.png "Robotz main screen"

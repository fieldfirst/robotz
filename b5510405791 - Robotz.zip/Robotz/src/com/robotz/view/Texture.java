package com.robotz.view;

import java.awt.Color;

import javax.swing.JPanel;

public class Texture extends JPanel {

	private Color backgroundColor = Color.green;
	
	public Texture() {
		setBackground(backgroundColor);
	}
}

package com.robotz.model.parsetree;

public class NodeRobot implements Node {

	private final String nodeType = "robot";
	private String v;
	private Node a;
	private Node b;

	@Override
	public String getNodeType() {
		return this.nodeType;
	}
	
	public void setVReference(String vReference) {
		this.v = vReference;
	}
	
	public void setV(String v) {
		this.v = v;
	}
	
	public String getV() {
		return this.v;
	}
	
	public void setANode(Node aNode) {
		this.a = aNode;
	}
	
	public void setBNode(Node bNode) {
		this.b = bNode;
	}
	
	public Node getANode() {
		return this.a;
	}
	
	public Node getBNode() {
		return this.b;
	}
	

}
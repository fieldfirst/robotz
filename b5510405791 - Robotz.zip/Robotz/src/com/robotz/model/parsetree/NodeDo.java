package com.robotz.model.parsetree;

public class NodeDo implements Node {

	private final String nodeType = "do";
	private Node L;
	private Node a;
	private Node b;
	
	@Override
	public String getNodeType() {
		return nodeType;
	}
	
	public void setLNode(Node lNode) {
		this.L = lNode;
	}
	
	public Node getLNode() {
		return this.L;
	}
	
	public void setANode(Node aNode) {
		this.a = aNode;
	}
	
	public Node getANode() {
		return this.a;
	}
	
	public void setBNode(Node bNode) {
		this.b = bNode;
	}
	
	public Node getBNode() {
		return this.b;
	}
}

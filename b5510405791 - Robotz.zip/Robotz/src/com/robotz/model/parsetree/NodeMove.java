package com.robotz.model.parsetree;

public class NodeMove implements Node {

	private final String nodeType = "move";
	private String v;
	private String d;
	private Node a;
	
	@Override
	public String getNodeType() {
		return nodeType;
	}
	
	public void setVReference(String vReference) {
		this.v = vReference;
	}
	
	public void setV(String v) {
		this.v = v;
	}
	
	public String getV() {
		return this.v;
	}
	
	public void setD(String d) {
		this.d = d;
	}
	
	public String getD() {
		return this.d;
	}
	
	public void setANode(Node aNode) {
		this.a = aNode;
	}
	
	public Node getANode() {
		return this.a;
	}

}

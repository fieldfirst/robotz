package com.robotz.model.parsetree;

public interface Node {
	public String getNodeType();
}

package com.robotz.model.parsetree;

public class NodeObstacle implements Node {

	private final String nodeType = "obst";
	private Node a;
	private Node b;
	
	@Override
	public String getNodeType() {
		return nodeType;
	}
	
	public void setANode(Node aNode) {
		this.a = aNode;
	}
	
	public void setBNode(Node bNode) {
		this.b = bNode;
	}
	
	public Node getANode() {
		return this.a;
	}
	
	public Node getBNode() {
		return this.b;
	}

}

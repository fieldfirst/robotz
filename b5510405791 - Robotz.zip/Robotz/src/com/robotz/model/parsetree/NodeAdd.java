package com.robotz.model.parsetree;

public class NodeAdd implements Node {

	private final String nodeType = "add";
	private Node a;
	private String v;
	
	@Override
	public String getNodeType() {
		return nodeType;
	}
	
	public void setANode(Node aNode) {
		this.a = aNode;
	}
	
	public Node getANode() {
		return this.a;
	}
	
	public void setVReference(String vReference) {
		this.v = vReference;
	}
	
	public String getV() {
		return this.v;
	}
	
	public void setV(String v) {
		this.v = v;
	}

}

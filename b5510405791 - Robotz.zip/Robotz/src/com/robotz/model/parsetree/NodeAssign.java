package com.robotz.model.parsetree;

public class NodeAssign implements Node {
	
	private final String nodeType = "assn";
	private String v;
	private Node a;

	@Override
	public String getNodeType() {
		return nodeType;
	}
	
	public Node getANode() {
		return this.a;
	}
	
	public void setANode(Node aNode) {
		this.a = aNode;
	}
	
	public void setVReference(String vReference) {
		this.v = vReference;
	}
	
	public void setV(String v) {
		this.v = v;
	}
	
	public String getV() {
		return this.v;
	}

}

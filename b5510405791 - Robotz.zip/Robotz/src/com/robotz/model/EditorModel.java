package com.robotz.model;


public class EditorModel {
	
	private boolean isDocumentEdited;

}
